# IBM Cloud Collection — Required Changes
## `failedrequest/ansible-ibmcloud`

Four files need changes. One new file must be created.
All changes are independent — each file can be worked on separately.

---

## File 1 — `plugins/modules/ibm_is_virtual_network_interface.py`

Two separate bugs in this file. Fix both.

---

### Change 1-A — Add `primary_ip_id` parameter

**Why:** The playbook creates reserved IP objects first, then creates VNIs bound
to those IPs by their resource ID. The API call is:
```json
POST /virtual_network_interfaces
{
  "primary_ip": { "id": "<reserved-ip-id>" }
}
```
The module only supports `primary_ip_address` (IP string) and `primary_ip_name`
(name string). Neither binds to an existing reserved IP object — they tell the
VPC to create a new one. This produces duplicate IPs or a `400` conflict error.

---

**Step 1 — Add `primary_ip_id` to `argument_spec` at the bottom of the file.**

Find this block (currently the last block before `if __name__`):
```python
    argument_spec.update({
        'name': {'type': 'str', 'required': True},
        'id': {'type': 'str', 'required': False},
        'subnet': {'type': 'str', 'required': False},
        'security_groups': {'type': 'list', 'elements': 'str', 'required': False},
        'enable_infrastructure_nat': {'type': 'bool', 'required': False, 'default': True},
        'primary_ip_address': {'type': 'str', 'required': False},
        'primary_ip_name': {'type': 'str', 'required': False}
    })

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )
```

Replace with:
```python
    argument_spec.update({
        'name': {'type': 'str', 'required': True},
        'id': {'type': 'str', 'required': False},
        'subnet': {'type': 'str', 'required': False},
        'security_groups': {'type': 'list', 'elements': 'str', 'required': False},
        'enable_infrastructure_nat': {'type': 'bool', 'required': False, 'default': True},
        'primary_ip_id': {'type': 'str', 'required': False},
        'primary_ip_address': {'type': 'str', 'required': False},
        'primary_ip_name': {'type': 'str', 'required': False}
    })

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
        mutually_exclusive=[
            ['primary_ip_id', 'primary_ip_address'],
            ['primary_ip_id', 'primary_ip_name'],
        ]
    )
```

---

**Step 2 — Wire `primary_ip_id` into `create_resource()`.**

Find this block inside `create_resource()`:
```python
            # Add primary IP configuration with reserved IP
            reserved_ip_address = self.params.get('primary_ip_address')
            reserved_ip_name = self.params.get('primary_ip_name')

            if reserved_ip_address or reserved_ip_name:
                primary_ip = {}
                if reserved_ip_address:
                    primary_ip['address'] = reserved_ip_address
                if reserved_ip_name:
                    primary_ip['name'] = reserved_ip_name
                prototype_kwargs['primary_ip'] = primary_ip
```

Replace with:
```python
            # Add primary IP configuration with reserved IP
            reserved_ip_id      = self.params.get('primary_ip_id')
            reserved_ip_address = self.params.get('primary_ip_address')
            reserved_ip_name    = self.params.get('primary_ip_name')

            if reserved_ip_id or reserved_ip_address or reserved_ip_name:
                primary_ip = {}
                if reserved_ip_id:
                    primary_ip['id'] = reserved_ip_id
                if reserved_ip_address:
                    primary_ip['address'] = reserved_ip_address
                if reserved_ip_name:
                    primary_ip['name'] = reserved_ip_name
                prototype_kwargs['primary_ip'] = primary_ip
```

---

**Step 3 — Add `primary_ip_id` to the `DOCUMENTATION` options block.**

Inside the `DOCUMENTATION = r'''` string, after the `enable_infrastructure_nat`
option entry, add:
```yaml
    primary_ip_id:
        description:
            - ID of an existing reserved IP object to bind as the primary IP.
            - Use this when the reserved IP was pre-created separately and must
              be bound to this VNI by its resource ID.
            - Mutually exclusive with primary_ip_address and primary_ip_name.
        type: str
        required: false
    primary_ip_address:
        description:
            - IPv4 address string to request as the primary IP.
            - If no reserved IP with this address exists, the VPC creates a new one.
            - Mutually exclusive with primary_ip_id.
        type: str
        required: false
    primary_ip_name:
        description:
            - Name to assign to the automatically created primary reserved IP.
            - Mutually exclusive with primary_ip_id.
        type: str
        required: false
```

---

### Change 1-B — Fix `delete_resource()` (wrong SDK method + missing async wait)

**Why (bug 1):** The current code calls
`self.vpc_service.delete_virtual_network_interfaces(id=resource_id)` — the
method name is **plural** (`delete_virtual_network_interfaces`). That method
does not exist in the IBM VPC Python SDK. The correct single-resource delete
method is `delete_virtual_network_interface` (singular). This will raise an
`AttributeError` at runtime.

**Why (bug 2):** The VPC API returns `HTTP 202 Accepted` for VNI deletes — the
operation is asynchronous. The module must poll until the VNI is gone before
returning. If the caller proceeds to delete the subnet immediately after this
module returns, the subnet delete will fail with
`409 vni_in_use_target_exists` because the VNI is still being torn down.

---

Find the entire `delete_resource` method:
```python
    def delete_resource(self, resource_id: str):
        """Delete a resource."""
        self.check_mode_exit(changed=True, msg=f"Would delete virtual_network_interface: {resource_id}")

        try:
            # Use the correct SDK method name (plural)
            self.vpc_service.delete_virtual_network_interfaces(
                id=resource_id
            )
            self.result['changed'] = True
            self.result['msg'] = f"virtual_network_interface {resource_id} deleted successfully"
        except ApiException as e:
            self.handle_api_exception(e, f"delete virtual_network_interface {resource_id}")
```

Replace with:
```python
    def delete_resource(self, resource_id: str):
        """Delete a VNI and poll until the async deletion completes (API returns 202)."""
        import time

        self.check_mode_exit(changed=True, msg=f"Would delete virtual_network_interface: {resource_id}")

        # Issue the delete — singular method is correct
        try:
            self.vpc_service.delete_virtual_network_interface(id=resource_id)
        except ApiException as e:
            if e.code == 404:
                # Already gone — treat as success
                self.result['msg'] = f"virtual_network_interface {resource_id} not found (already deleted)"
                return
            self.handle_api_exception(e, f"delete virtual_network_interface {resource_id}")

        # Poll until the VNI no longer exists.
        # The API returns 202 Accepted — the resource is deleted asynchronously.
        # Callers (e.g. subnet delete) depend on this completing before proceeding.
        wait_seconds = self.params.get('delete_wait_seconds', 60)
        poll_interval = 5
        elapsed = 0
        while elapsed < wait_seconds:
            time.sleep(poll_interval)
            elapsed += poll_interval
            try:
                self.vpc_service.get_virtual_network_interface(id=resource_id)
                # Still exists — keep waiting
            except ApiException as e:
                if e.code == 404:
                    # Confirmed deleted
                    break
                self.handle_api_exception(e, f"poll deletion of virtual_network_interface {resource_id}")
        else:
            self.fail_json(
                msg=(
                    f"virtual_network_interface {resource_id} still exists after "
                    f"{wait_seconds}s; subnet delete may fail"
                )
            )

        self.result['changed'] = True
        self.result['msg'] = f"virtual_network_interface {resource_id} deleted successfully"
```

Also add `delete_wait_seconds` to `argument_spec`:
```python
        'delete_wait_seconds': {'type': 'int', 'required': False, 'default': 60}
```

And add to `DOCUMENTATION`:
```yaml
    delete_wait_seconds:
        description:
            - Maximum seconds to wait for an async VNI deletion to complete.
            - The VPC API returns 202 Accepted on DELETE; the module polls
              GET until the resource is gone (404) before returning.
            - Increase this value in environments where VNI teardown is slow.
        type: int
        required: false
        default: 60
```

---

## File 2 — `plugins/modules/ibm_is_subnet_reserved_ip.py`

One change needed.

---

### Change 2-A — Remove `required_one_of` and add list mode with `owner` filter

**Why:** The playbook needs to list **all** reserved IPs in a subnet (to build a
name→ID map) and then filter to `owner == "user"` to exclude VPC-managed IPs
(gateway, broadcast, etc.). The current module enforces
`required_one_of=[['name', 'id']]`, which means you cannot call it without
specifying a resource — it cannot be used as a data source.

---

**Step 1 — Remove `required_one_of` from `AnsibleModule` constructor.**

Find:
```python
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
        required_one_of=[['name', 'id']]
    )
```

Replace with:
```python
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )
```

---

**Step 2 — Add `owner` parameter to `argument_spec`.**

Find:
```python
    argument_spec.update({
        'subnet_id': {'type': 'str', 'required': True},
        'name': {'type': 'str', 'required': False},
        'id': {'type': 'str', 'required': False},
        'address': {'type': 'str', 'required': False},
        'auto_delete': {'type': 'bool', 'required': False},
        'target': {'type': 'str', 'required': False},
    })
```

Replace with:
```python
    argument_spec.update({
        'subnet_id': {'type': 'str', 'required': True},
        'name': {'type': 'str', 'required': False},
        'id': {'type': 'str', 'required': False},
        'address': {'type': 'str', 'required': False},
        'auto_delete': {'type': 'bool', 'required': False},
        'target': {'type': 'str', 'required': False},
        'owner': {
            'type': 'str',
            'required': False,
            'choices': ['user', 'provider'],
            'default': None
        },
    })
```

---

**Step 3 — Add list mode to `run()`.**

Find the entire `run()` method:
```python
    def run(self):
        """Execute the module logic."""
        existing_resource = None

        if self.resource_id:
            existing_resource = self.get_resource(self.resource_id)
        elif self.resource_name:
            reserved_ips = self.list_resources()
            for rip in reserved_ips:
                if rip.get('name') == self.resource_name:
                    existing_resource = rip
                    break

        if self.state == 'present':
            if existing_resource:
                self.update_resource(existing_resource)
            else:
                self.create_resource()

        elif self.state == 'absent':
            if existing_resource:
                self.delete_resource(existing_resource['id'])
            else:
                self.result['msg'] = "Reserved IP not found"

        self.exit_json()
```

Replace with:
```python
    def run(self):
        """Execute the module logic."""
        owner_filter = self.params.get('owner')

        # ── List mode ─────────────────────────────────────────────────────────
        # When neither name nor id is given, return all reserved IPs in the
        # subnet (optionally filtered by owner).  State is ignored in list mode.
        if not self.resource_id and not self.resource_name:
            all_rips = self.list_resources()
            if owner_filter:
                all_rips = [r for r in all_rips if r.get('owner') == owner_filter]
            self.result['resources'] = all_rips
            self.result['msg'] = (
                f"Found {len(all_rips)} reserved IP(s) in subnet {self.subnet_id}"
                + (f" (owner={owner_filter})" if owner_filter else "")
            )
            self.exit_json()
            return

        # ── Single-resource mode ───────────────────────────────────────────────
        existing_resource = None

        if self.resource_id:
            existing_resource = self.get_resource(self.resource_id)
        elif self.resource_name:
            reserved_ips = self.list_resources()
            for rip in reserved_ips:
                if rip.get('name') == self.resource_name:
                    existing_resource = rip
                    break

        if self.state == 'present':
            if existing_resource:
                self.update_resource(existing_resource)
            else:
                self.create_resource()

        elif self.state == 'absent':
            if existing_resource:
                self.delete_resource(existing_resource['id'])
            else:
                self.result['msg'] = "Reserved IP not found"

        self.exit_json()
```

---

**Step 4 — Add `owner` and `resources` to `DOCUMENTATION`/`RETURN`.**

Add to the `DOCUMENTATION` options:
```yaml
    owner:
        description:
            - When neither C(name) nor C(id) is given, filter the returned list
              by owner type.
            - C(user) — only reserved IPs created by the user (safe to bind to VNIs).
            - C(provider) — only VPC-managed IPs (gateway, broadcast, etc.).
            - Omit to return all reserved IPs.
            - Only relevant in list mode (when name and id are both omitted).
        type: str
        required: false
        choices: ['user', 'provider']
```

Add to `RETURN`:
```yaml
resources:
    description: List of reserved IP resources (returned in list mode when name and id are omitted)
    returned: when name and id are both omitted
    type: list
    elements: dict
```

---

## File 3 — `plugins/modules/ibm_ks_cluster_vni.py`

Three separate bugs. Fix all three.

---

### Change 3-A — Add `vlan` parameter and use `baremetal` subcommand in `attach_vni()`

**Why:** The ROKS `ibmcloud ks vni attach` command for bare metal workers
requires the `baremetal` subcommand and a `--vlan <id>` flag. Without `--vlan`,
the attachment succeeds at the API level but the VNI is not tagged with the
correct VLAN, and OVN-K Localnet traffic cannot flow. The current attach command
is:
```
ibmcloud ks vni attach --cluster ... --vni ... --subnet ...
```
It should be:
```
ibmcloud ks vni attach baremetal --cluster ... --vni ... --vlan ...
```

---

**Step 1 — Add `vlan` to `argument_spec`.**

Find:
```python
    argument_spec = {
        'cluster': {'type': 'str', 'required': True},
        'vni_id': {'type': 'str', 'required': True},
        'vni_subnet_id': {'type': 'str', 'required': False},
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'ibmcloud_api_key': {'type': 'str', 'required': False, 'no_log': True},
        'region': {'type': 'str', 'required': False}
    }
```

Replace with:
```python
    argument_spec = {
        'cluster': {'type': 'str', 'required': True},
        'vni_id': {'type': 'str', 'required': True},
        'vni_subnet_id': {'type': 'str', 'required': False},
        'vlan': {'type': 'int', 'required': False},
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'ibmcloud_api_key': {'type': 'str', 'required': False, 'no_log': True},
        'region': {'type': 'str', 'required': False}
    }
```

---

**Step 2 — Store `vlan` in `__init__`.**

Find inside `__init__`:
```python
        self.vni_subnet_id = module.params.get('vni_subnet_id')
```

Replace with:
```python
        self.vni_subnet_id = module.params.get('vni_subnet_id')
        self.vlan = module.params.get('vlan')
```

---

**Step 3 — Rewrite the attach command in `attach_vni()`.**

Find inside `attach_vni()`:
```python
        # Attach VNI
        cmd = f"ibmcloud ks vni attach --cluster {self.cluster} --vni {self.vni_id} --subnet {self.vni_subnet_id}"
        rc, stdout, stderr = self._run_command(cmd, check_rc=False)

        if rc != 0:
            self.module.fail_json(
                msg=f"Failed to attach VNI {self.vni_id} to cluster {self.cluster}",
                stdout=stdout,
                stderr=stderr,
                rc=rc
            )

        self.result['changed'] = True
        self.result['msg'] = f"VNI {self.vni_id} attached to cluster {self.cluster} successfully"
        self.result['vni_info'] = {
            'vni_id': self.vni_id,
            'subnet_id': self.vni_subnet_id,
            'cluster': self.cluster
        }
```

Replace with:
```python
        # Attach VNI — bare metal ROKS nodes use the baremetal subcommand + --vlan
        if self.vlan is not None:
            cmd = (
                f"ibmcloud ks vni attach baremetal"
                f" --cluster-id {self.cluster}"
                f" --vni {self.vni_id}"
                f" --vlan {self.vlan}"
                f" -q"
            )
        else:
            cmd = (
                f"ibmcloud ks vni attach"
                f" --cluster-id {self.cluster}"
                f" --vni {self.vni_id}"
                f" --subnet {self.vni_subnet_id}"
                f" -q"
            )
        rc, stdout, stderr = self._run_command(cmd, check_rc=False)

        if rc != 0:
            self.module.fail_json(
                msg=f"Failed to attach VNI {self.vni_id} to cluster {self.cluster}",
                stdout=stdout,
                stderr=stderr,
                rc=rc
            )

        self.result['changed'] = True
        self.result['msg'] = f"VNI {self.vni_id} attached to cluster {self.cluster} successfully"
        self.result['vni_info'] = {
            'vni_id': self.vni_id,
            'vlan': self.vlan,
            'cluster': self.cluster
        }
```

---

**Step 4 — Add `vlan` to `DOCUMENTATION`.**

After the `vni_subnet_id` option, add:
```yaml
    vlan:
        description:
            - VLAN ID to tag the VNI attachment on bare metal ROKS workers.
            - When provided, the C(baremetal) subcommand is used:
              C(ibmcloud ks vni attach baremetal --cluster-id ... --vni ... --vlan ...).
            - Required for OVN-K Localnet secondary networks on bare metal nodes.
            - When omitted, the standard attach command is used with C(--subnet).
        type: int
        required: false
```

---

### Change 3-B — Add `-f` force flag to `detach_vni()`

**Why:** The `ibmcloud ks vni detach` command prompts for confirmation when run
interactively. Without `-f`, the command blocks waiting for stdin input and
never completes in an Ansible run.

Find inside `detach_vni()`:
```python
        # Detach VNI
        cmd = f"ibmcloud ks vni detach --cluster {self.cluster} --vni {self.vni_id}"
```

Replace with:
```python
        # Detach VNI — -f bypasses the interactive confirmation prompt
        cmd = f"ibmcloud ks vni detach --cluster-id {self.cluster} --vni {self.vni_id} -f -q"
```

---

### Change 3-C — Fix `_is_vni_attached()` to use `ibmcloud ks vni ls`

**Why:** The current `_get_cluster_vnis()` and `_is_vni_attached()` parse the
output of `ibmcloud ks cluster get`, which does not reliably include VNI
attachment data across all cluster versions. The correct command is
`ibmcloud ks vni ls --cluster-id <id> --output json`, which returns a GraphQL
response that includes `virtualNetworkInterface.externalID` — the VNI ID.

The current code will always return `False` for `_is_vni_attached()` on most
clusters, causing the module to attempt a duplicate attach on every run.

---

Replace the entire `_get_cluster_vnis` and `_is_vni_attached` methods:

```python
    def _get_attached_vni_ids(self):
        """
        Return the set of VNI IDs currently attached to the cluster.
        Uses 'ibmcloud ks vni ls' which returns the correct attachment data.
        """
        cmd = f"ibmcloud ks vni ls --cluster-id {self.cluster} --output json"
        rc, stdout, stderr = self._run_command(cmd, check_rc=False)

        if rc != 0:
            self.module.fail_json(
                msg=f"Failed to list VNIs for cluster {self.cluster}: {stderr}",
                stdout=stdout,
                stderr=stderr,
                rc=rc
            )

        try:
            data = json.loads(stdout)
            edges = (
                data.get('data', {})
                    .get('node', {})
                    .get('networkAttachments', {})
                    .get('edges', [])
            )
            return {
                edge['node']['virtualNetworkInterface']['externalID']
                for edge in edges
                if edge.get('node', {})
                         .get('virtualNetworkInterface', {})
                         .get('externalID')
            }
        except (KeyError, ValueError, json.JSONDecodeError) as exc:
            self.module.fail_json(
                msg=f"Failed to parse VNI list for cluster {self.cluster}: {exc}",
                stdout=stdout
            )

    def _is_vni_attached(self):
        """Check if this module's vni_id is attached to the cluster."""
        return self.vni_id in self._get_attached_vni_ids()
```

Also update all call-sites of the old `_get_cluster_vnis()` — the method is
now replaced by `_get_attached_vni_ids()`. The old `_get_cluster_vnis` and
`_validate_cluster_exists` methods that run `cluster get` can be kept as-is,
or the `_validate_cluster_exists` can remain and `_get_cluster_vnis` deleted
since `_is_vni_attached` now calls `_get_attached_vni_ids` instead.

The `attach_vni()` method currently calls:
```python
        if self._is_vni_attached():
```
That call is fine — it will now go through `_get_attached_vni_ids()`. No other
changes needed in the call-sites.

---

## File 4 — `plugins/modules/ibm_is_vpc_info.py`

One change needed.

---

### Change 4-A — Use server-side `name` filter in `get_resource_by_name()`

**Why:** The current implementation calls `list_vpcs()` with no parameters,
fetches every VPC in the entire region, then does a client-side linear scan for
a matching name. When two VPCs in the same account and region have the same
name, it returns whichever one comes first in the unordered list — which may be
the wrong one. This caused the original wrong-VPC bug (resources created in
`sao-br-site-a` when `sao-br-site-b` was intended).

The IBM VPC Python SDK's `list_vpcs()` accepts a `name` keyword argument which
passes `?name=<value>` as a server-side filter. The API guarantees an exact
match on the name field — it returns only VPCs in the current account and
region with that exact name.

---

Find `get_resource_by_name()`:
```python
    def get_resource_by_name(self, resource_name: str):
        """Get VPC by name."""
        try:
            response = self.vpc_service.list_vpcs()
            vpcs = response.get_result().get('vpcs', [])

            for vpc in vpcs:
                if vpc.get('name') == resource_name:
                    return vpc

            return None
        except ApiException as e:
            self.handle_api_exception(e, f"list VPCs to find {resource_name}")
```

Replace with:
```python
    def get_resource_by_name(self, resource_name: str):
        """
        Get VPC by name using server-side name filter.
        Passes ?name=<resource_name> to the API so only the matching VPC is
        returned — avoids client-side linear scan and cross-account collisions
        when multiple VPCs share the same name.
        """
        try:
            response = self.vpc_service.list_vpcs(name=resource_name)
            vpcs = response.get_result().get('vpcs', [])
            return vpcs[0] if vpcs else None
        except ApiException as e:
            self.handle_api_exception(e, f"list VPCs to find {resource_name}")
```

No `argument_spec` or `DOCUMENTATION` changes needed — the parameter interface
is unchanged.

---

## New File — `plugins/modules/ibm_is_subnet_reserved_ip_info.py`

The existing `ibm_is_subnet_reserved_ip` is a CRUD module — it works on a
single IP by `name` or `id`. The playbooks need to list all reserved IPs across
several subnets and filter them for building a name→ID map. The list mode added
in File 2 handles this, but having a dedicated read-only `_info` module is
cleaner and consistent with the pattern used by `ibm_is_subnet_info` and
`ibm_is_virtual_network_interface_info`.

Create the file at:
`plugins/modules/ibm_is_subnet_reserved_ip_info.py`

Full content:

```python
#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2024, IBM Cloud Team
# BSD 2-Clause License (see LICENSE or https://opensource.org/licenses/BSD-2-Clause)

DOCUMENTATION = r'''
---
module: ibm_is_subnet_reserved_ip_info
short_description: List reserved IPs within an IBM Cloud VPC subnet
version_added: "1.0.0"
description:
    - Retrieve all reserved IPs within a subnet.
    - Optionally filter by owner type to separate user-created IPs from
      VPC-managed ones (gateways etc.).
    - This is a read-only info module; it does not modify any resources.
requirements:
    - ibm-vpc >= 0.33.0
    - ibm-cloud-sdk-core >= 3.20.0
options:
    subnet_id:
        description:
            - ID of the subnet to query.
        type: str
        required: true
    owner:
        description:
            - Filter reserved IPs by owner type.
            - C(user) — only IPs created by the account user.  Safe to bind
              to a Virtual Network Interface.
            - C(provider) — only VPC-managed IPs (default gateway, broadcast,
              etc.).
            - Omit to return all reserved IPs regardless of owner.
        type: str
        required: false
        choices: ['user', 'provider']
    ibmcloud_api_key:
        description:
            - IBM Cloud API key.
            - Can also be set via IC_API_KEY or IBMCLOUD_API_KEY environment
              variable.
        type: str
        required: false
        no_log: true
    region:
        description:
            - IBM Cloud region.
        type: str
        required: false
        default: us-south
        choices:
            - us-south
            - us-east
            - eu-gb
            - eu-de
            - jp-tok
            - au-syd
            - jp-osa
            - ca-tor
            - br-sao
author:
    - IBM Cloud Team
'''

EXAMPLES = r'''
- name: List all reserved IPs in a subnet
  ibm_is_subnet_reserved_ip_info:
    subnet_id: 0717-aabbccdd-1234-1234-1234-aabbccddeeff
    region: br-sao
  register: all_rips

- name: List only user-created reserved IPs
  ibm_is_subnet_reserved_ip_info:
    subnet_id: 0717-aabbccdd-1234-1234-1234-aabbccddeeff
    owner: user
    region: br-sao
  register: user_rips

- name: Build a name-to-id map of user reserved IPs
  ansible.builtin.set_fact:
    rip_id_map: >-
      {{
        rip_id_map | default({}) |
        combine({ item.name: item.id })
      }}
  loop: "{{ user_rips.resources }}"
  loop_control:
    label: "{{ item.name }}"
'''

RETURN = r'''
resources:
    description: List of reserved IP objects in the subnet.
    returned: always
    type: list
    elements: dict
    contains:
        id:
            description: Reserved IP resource ID.
            type: str
            sample: "0717-11223344-aaaa-bbbb-cccc-112233445566"
        name:
            description: Reserved IP name.
            type: str
            sample: "rip-web-01"
        address:
            description: The reserved IP address.
            type: str
            sample: "10.18.20.10"
        owner:
            description: >
                Who owns the reserved IP.
                C(user) for user-created; C(provider) for VPC-managed.
            type: str
            sample: "user"
        auto_delete:
            description: Whether the IP is auto-deleted when its target is deleted.
            type: bool
        lifecycle_state:
            description: Current lifecycle state.
            type: str
            sample: "stable"
        href:
            description: URL for this reserved IP.
            type: str
        resource_type:
            description: The resource type.
            type: str
            sample: "subnet_reserved_ip"
        target:
            description: The target this reserved IP is bound to (if any).
            type: dict
found:
    description: True if at least one reserved IP was found.
    returned: always
    type: bool
msg:
    description: Status message.
    returned: always
    type: str
'''

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.ibm.cloudcollection.plugins.module_utils.ibm_cloud_sdk import (
    IBMCloudSDKModule,
    get_common_argument_spec
)

try:
    from ibm_vpc import VpcV1
    from ibm_cloud_sdk_core import ApiException
    HAS_IBM_VPC = True
except ImportError:
    HAS_IBM_VPC = False


class IBMSubnetReservedIPInfoModule(IBMCloudSDKModule):
    """IBM Cloud Subnet Reserved IP info module."""

    def __init__(self, module):
        super().__init__(module)

        if not HAS_IBM_VPC:
            self.fail_json(msg="ibm-vpc Python SDK is required")

        self.vpc_service = VpcV1(authenticator=self.auth.get_authenticator())
        self.vpc_service.set_service_url(
            f'https://{self.region}.iaas.cloud.ibm.com/v1'
        )

        self.subnet_id = self.params.get('subnet_id')
        self.owner_filter = self.params.get('owner')

    def list_resources(self):
        """List all reserved IPs in the subnet, with optional owner filter."""
        try:
            response = self.vpc_service.list_subnet_reserved_ips(
                subnet_id=self.subnet_id
            )
            rips = response.get_result().get('reserved_ips', [])
            if self.owner_filter:
                rips = [r for r in rips if r.get('owner') == self.owner_filter]
            return rips
        except ApiException as e:
            self.handle_api_exception(
                e, f"list reserved IPs in subnet {self.subnet_id}"
            )

    def run(self):
        resources = self.list_resources()
        self.result['resources'] = resources
        self.result['found'] = len(resources) > 0
        self.result['msg'] = (
            f"Found {len(resources)} reserved IP(s) in subnet {self.subnet_id}"
            + (f" (owner={self.owner_filter})" if self.owner_filter else "")
        )
        self.exit_json()


def main():
    argument_spec = get_common_argument_spec()
    argument_spec.update({
        'subnet_id': {'type': 'str', 'required': True},
        'owner': {
            'type': 'str',
            'required': False,
            'choices': ['user', 'provider'],
            'default': None
        },
    })

    # Info module — no state parameter
    if 'state' in argument_spec:
        del argument_spec['state']

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    info_module = IBMSubnetReservedIPInfoModule(module)
    info_module.run()


if __name__ == '__main__':
    main()
```

---

## Summary

| File | Change | Impact |
|---|---|---|
| `ibm_is_virtual_network_interface.py` | Add `primary_ip_id` param + wire into `create_resource()` | Unblocks VNI creation from `uri` → collection module |
| `ibm_is_virtual_network_interface.py` | Fix `delete_resource()` — singular SDK method + async poll | Unblocks VNI deletion from `uri` → collection module |
| `ibm_is_subnet_reserved_ip.py` | Remove `required_one_of`, add list mode + `owner` filter | Unblocks reserved IP list/filter from `uri` → collection module |
| `ibm_ks_cluster_vni.py` | Add `vlan` + `baremetal` subcommand to attach | Unblocks VNI attach from `ansible.builtin.command` → collection module |
| `ibm_ks_cluster_vni.py` | Add `-f -q` to detach | Fixes silent hang in non-interactive Ansible runs |
| `ibm_ks_cluster_vni.py` | Fix `_is_vni_attached()` to use `vni ls` | Fixes idempotency — currently always re-attaches |
| `ibm_is_vpc_info.py` | Server-side `name=` filter in `get_resource_by_name()` | Eliminates cross-account VPC collision (root cause of original bug) |
| `ibm_is_subnet_reserved_ip_info.py` | New file | Clean read-only list+filter companion for reserved IPs |

Once these 8 changes are applied, every `ansible.builtin.uri` call in
`net-cloud.yml` and `net-cloud-cleanup.yml`, and both `ansible.builtin.command`
calls in `net-openshift.yml`, can be replaced with collection modules.
